from flask import Flask, render_template, jsonify, request
import cv2, os, json, face_recognition, numpy as np
from datetime import datetime
import base64, re
import matplotlib.pyplot as plt
import csv
import threading

app = Flask(__name__, template_folder='../templates', static_folder='../static')

# ---------------- Paths ----------------
img_path = "ImagesAttendance"
graph_folder = os.path.join(app.static_folder, "AttendanceGraphs")
os.makedirs(graph_folder, exist_ok=True)
attendance_file = "attendance_history.json"
csv_file = r"C:\\Users\\VIDWAN\\OneDrive\\Documents\\smart_attendance\\ImagesAttendance\\AI IN EDUCATION(DATASSET).csv"

# ---------------- Load CSV Dataset ----------------
student_names, roll_numbers, images = [], [], []

with open(csv_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        roll_numbers.append(row.get('ROLL NO', f'RN{len(roll_numbers)+1}'))
        student_names.append(row.get('NAME', f'Student{len(student_names)+1}'))
        photo_path = os.path.join(img_path, row.get('PHOTO', ''))
        if os.path.exists(photo_path):
            img = cv2.imread(photo_path)
            images.append(img)
        else:
            images.append(np.zeros((100,100,3), dtype=np.uint8))  # placeholder

# ---------------- Encode Faces ----------------
def findEncodings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encodes = face_recognition.face_encodings(img)
        encodeList.append(encodes[0] if encodes else np.zeros(128))
    return encodeList

encodeListKnown = findEncodings(images)

# ---------------- Load or Initialize JSON ----------------
if os.path.exists(attendance_file):
    with open(attendance_file, "r") as f:
        attendance_history = json.load(f)
else:
    attendance_history = {name: {"records": {}, "streak": 0, "highest_streak": 0, "total_days": 0, "total_present": 0} for name in student_names}

# ----------------- Home Route -----------------
@app.route("/")
def home():
    table_data = []
    for i, name in enumerate(student_names, start=1):
        data = attendance_history.get(name, {})
        # Initial zeros / "-"
        total_days = data.get("total_days", 0)
        total_present = data.get("total_present", 0)
        avg_attendance = round(total_present/total_days*100,2) if total_days>0 else 0
        last_status = list(data.get("records", {}).values())[-1] if total_days>0 else "-"
        streak = data.get("streak",0) if total_days>0 else 0
        highest_streak = data.get("highest_streak",0) if total_days>0 else 0
        
        table_data.append({
            "sno": i,
            "name": name,
            "status": last_status if total_days>0 else "-",
            "streak": streak,
            "highest_streak": highest_streak,
            "total_days": total_days if total_days>0 else 0,
            "total_present": total_present if total_days>0 else 0,
            "avg_attendance": avg_attendance if total_days>0 else 0,
        })
    
    leaderboard = sorted(table_data, key=lambda x: x['highest_streak'], reverse=True)
    
    # Graph placeholders if not exist
    for name in student_names:
        graph_path = os.path.join(graph_folder, f"{name}_attendance.png")
        if not os.path.exists(graph_path):
            plt.figure(figsize=(6,3))
            plt.text(0.5,0.5,"-",fontsize=20,ha='center')
            plt.axis('off')
            plt.savefig(graph_path)
            plt.close()
    
    avg_graph_path = os.path.join(graph_folder,"average_attendance.png")
    if not os.path.exists(avg_graph_path):
        plt.figure(figsize=(6,3))
        plt.text(0.5,0.5,"-",fontsize=20,ha='center')
        plt.axis('off')
        plt.savefig(avg_graph_path)
        plt.close()

    return render_template("index.html", students=table_data, leaderboard=leaderboard)

# ----------------- Capture Attendance -----------------
@app.route("/capture", methods=["POST"])
def capture_attendance():
    data = request.json
    img_data = data["image"]
    img_str = re.sub('^data:image/.+;base64,', '', img_data)
    img_bytes = base64.b64decode(img_str)
    nparr = np.frombuffer(img_bytes, np.uint8)
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    annotated_b64, new_face_count = update_attendance(frame)
    
    # Prepare live table data for JS
    table_data = []
    for i, name in enumerate(student_names, start=1):
        d = attendance_history.get(name, {})
        total_days = d.get("total_days",0)
        total_present = d.get("total_present",0)
        avg = round(total_present/total_days*100,2) if total_days>0 else 0
        last_status = list(d.get("records", {}).values())[-1] if total_days>0 else "-"
        streak = d.get("streak",0)
        highest = d.get("highest_streak",0)
        table_data.append({
            "name": name,
            "status": last_status,
            "streak": streak,
            "highest_streak": highest,
            "total_days": total_days,
            "total_present": total_present,
            "avg_attendance": avg
        })
    
    return jsonify({
        "status":"success",
        "message":f"✅ Attendance captured! New Faces: {new_face_count}",
        "annotated_image":annotated_b64,
        "table_data": table_data
    })

# ---- Helper Functions ----
def save_json():
    with open(attendance_file, "w") as f:
        json.dump(attendance_history, f, indent=4)

def generate_graph(name):
    rec = attendance_history.get(name, {}).get("records", {})
    if not rec:
        plt.figure(figsize=(6,3))
        plt.text(0.5,0.5,"-",fontsize=20,ha='center')
        plt.axis('off')
        plt.savefig(os.path.join(graph_folder, f"{name}_attendance.png"))
        plt.close()
        return
    dates = sorted(rec.keys(), key=lambda x: datetime.strptime(x,"%d-%m-%Y"))
    x = np.arange(len(dates))
    cum = []
    total = 0
    for d in dates:
        if rec.get(d)=="P": total+=1
        cum.append(total)
    plt.figure(figsize=(6,3))
    plt.plot(x,cum, marker='o', color='#007BFF')
    plt.xticks(x, dates, rotation=45)
    plt.yticks(range(0,max(cum)+1))
    plt.xlabel("Dates")
    plt.ylabel("Cumulative Presence")
    plt.title(f"{name} Attendance")
    plt.tight_layout()
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.savefig(os.path.join(graph_folder, f"{name}_attendance.png"))
    plt.close()

def generate_avg_graph():
    all_dates = set()
    for name in student_names:
        all_dates.update(attendance_history.get(name, {}).get("records", {}).keys())
    if not all_dates:
        plt.figure(figsize=(6,3))
        plt.text(0.5,0.5,"-",fontsize=20,ha='center')
        plt.axis('off')
        plt.savefig(os.path.join(graph_folder,"average_attendance.png"))
        plt.close()
        return
    sorted_dates = sorted(all_dates, key=lambda x: datetime.strptime(x,"%d-%m-%Y"))
    cum_present = []
    for date in sorted_dates:
        count = 0
        for name in student_names:
            if attendance_history.get(name, {}).get("records", {}).get(date)=="P":
                count+=1
        cum_present.append(count/len(student_names)*100)
    plt.figure(figsize=(6,3))
    plt.plot(range(len(sorted_dates)), cum_present, marker='o', color='#FF5722')
    plt.xticks(range(len(sorted_dates)), sorted_dates, rotation=45)
    plt.ylim(0,100)
    plt.xlabel("Dates")
    plt.ylabel("Class Avg (%)")
    plt.title("Overall Class Average Attendance")
    plt.tight_layout()
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.savefig(os.path.join(graph_folder,"average_attendance.png"))
    plt.close()

def update_attendance(frame):
    small_frame = cv2.resize(frame, (0,0), fx=0.25, fy=0.25)
    rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
    faces = face_recognition.face_locations(rgb_small_frame, model="cnn")
    encodings = face_recognition.face_encodings(rgb_small_frame, faces)
    today = datetime.now().strftime("%d-%m-%Y")
    present_today = set()
    new_face_count = 0
    annotated_frame = frame.copy()
    THRESHOLD = 0.45

    for (top,right,bottom,left), encode in zip(faces, encodings):
        face_dis = face_recognition.face_distance(encodeListKnown, encode)
        if len(face_dis)>0:
            best_match_idx = np.argmin(face_dis)
            if face_dis[best_match_idx] < THRESHOLD:
                name = student_names[best_match_idx]
            else:
                new_face_count += 1
                name = f"NewFace{new_face_count}"
        else:
            new_face_count += 1
            name = f"NewFace{new_face_count}"

        present_today.add(name)
        top*=4; right*=4; bottom*=4; left*=4
        cv2.rectangle(annotated_frame, (left,top), (right,bottom), (0,255,0), 2)
        cv2.putText(annotated_frame,name,(left,top-10),cv2.FONT_HERSHEY_SIMPLEX,0.8,(0,255,0),2)

    # Update attendance table
    for name in student_names:
        if name not in attendance_history:
            attendance_history[name] = {"records":{},"streak":0,"highest_streak":0,"total_days":0,"total_present":0}
        d = attendance_history[name]
        d["total_days"] += 1
        if name in present_today:
            d["records"][today] = "P"
            d["streak"] = d.get("streak",0)+1
            d["highest_streak"] = max(d.get("highest_streak",0), d["streak"])
            d["total_present"] = d.get("total_present",0)+1
        else:
            d["records"][today] = "A"
            d["streak"] = 0

    # Async graph generation
    threading.Thread(target=lambda: [generate_graph(n) for n in student_names]).start()
    threading.Thread(target=generate_avg_graph).start()
    save_json()

    _, buffer = cv2.imencode('.jpg', annotated_frame)
    annotated_b64 = base64.b64encode(buffer).decode('utf-8')
    return annotated_b64, new_face_count

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)