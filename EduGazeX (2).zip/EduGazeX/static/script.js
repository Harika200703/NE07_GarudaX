// ---------------- SPLASH LOGIC ----------------
window.addEventListener('DOMContentLoaded', () => {
    setTimeout(()=>{
        const splash = document.getElementById('splashOverlay');
        splash.style.opacity = 0;
        setTimeout(()=> splash.style.display='none', 800);
        document.getElementById('mainContent').style.display='block';
    },1200);
});

// ---------------- CAMERA & ATTENDANCE ----------------
const canvas = document.getElementById('videoCanvas');
const ctx = canvas.getContext('2d');
const openBtn = document.getElementById('openCameraBtn');
const captureBtn = document.getElementById('captureBtn');
const statusText = document.getElementById('statusText');
let video = null;
let stream = null;

// Open camera
openBtn.addEventListener('click', async () => {
    if(video) return; 
    video = document.createElement('video');
    try {
        stream = await navigator.mediaDevices.getUserMedia({video:true});
        video.srcObject = stream;
        await video.play();
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        captureBtn.disabled = false;
        statusText.innerText = "🎬 Camera Ready";

        const renderLoop = () => {
            if(!video) return;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            requestAnimationFrame(renderLoop);
        };
        renderLoop();

    } catch(err) {
        alert("Camera access denied!");
        console.error(err);
    }
});

// Capture attendance
captureBtn.addEventListener('click', async () => {
    statusText.innerText = "📷 Capturing...";
    const captureCanvas = document.createElement('canvas');
    captureCanvas.width = video.videoWidth;
    captureCanvas.height = video.videoHeight;
    captureCanvas.getContext('2d').drawImage(video,0,0);
    const image_data = captureCanvas.toDataURL('image/jpeg');

    // Send to backend
    const res = await fetch("/capture", {
        method:"POST",
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({image:image_data})
    });
    const data = await res.json();

    // Show annotated image
    const img = new Image();
    img.src = "data:image/jpeg;base64,"+data.annotated_image;
    img.style.width="320px";
    img.style.display="block";
    statusText.innerText = data.message;
    statusText.appendChild(img);

    // -------- Update Table Live --------
    const table = document.querySelector("table tbody");
    data.table_data.forEach((row,i)=>{
        const tr = table.rows[i];
        tr.cells[2].innerText = row.status;
        tr.cells[3].innerText = row.streak;
        tr.cells[4].innerText = row.highest_streak;
        tr.cells[5].innerText = row.total_days;
        tr.cells[6].innerText = row.total_present;
        tr.cells[7].innerText = row.avg_attendance;
    });

    // -------- Update Graphs Live --------
    data.table_data.forEach(r=>{
        const g = document.getElementById(r.name+"_graph");
        if(g) g.src = "/static/AttendanceGraphs/"+r.name+"_attendance.png?"+new Date().getTime();
    });
    const avg = document.querySelector(".big-graph");
    avg.src = "/static/AttendanceGraphs/average_attendance.png?"+new Date().getTime();

    // Close camera
    if(stream) stream.getTracks().forEach(track=>track.stop());
    video = null;
    stream = null;
    captureBtn.disabled = true;
    statusText.innerText += " | 🎥 Camera Closed";
});